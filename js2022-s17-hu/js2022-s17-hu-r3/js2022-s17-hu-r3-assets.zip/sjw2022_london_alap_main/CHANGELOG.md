# Changelog
## 2021.12.02
 - Telepítőfájlok létrehozva
 - A PhpMyadmin automatikus indulásának kikapcsolása