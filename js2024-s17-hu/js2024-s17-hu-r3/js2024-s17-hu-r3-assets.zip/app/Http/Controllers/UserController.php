<?php

namespace App\Http\Controllers;

use App\Http\Requests\RegisterUserRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    function index()
    {
        return UserResource::collection(User::all());
    }
    
    function register(RegisterUserRequest $request)
    {
        $data = $request->validated();
        $data["name"] = "";
        $data["password"] = "";
        // return $data;
        // $data["name"] = mb_substr($data["last_name"],0,1) .
        $user = User::create($data);

        $user->name = mb_strtoupper(mb_substr($user->last_name,0,1)) . mb_strtoupper(mb_substr($user->first_name,0,1)) . $user->id;
        $user->save();
        return new UserResource($user);
    }
}
