<?php

namespace App\Http\Controllers;

use App\Http\Requests\StartRequest;
use App\Models\Machine;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;

class MachineController extends Controller
{

    public function start(StartRequest $request, int $id){
        $data = $request->validated();
        $user = User::where("name", "=", $data["name"])->where("pin", "=", $data["pincode"]);
        if(!$user)
        {
            abort(403);
        }
        $machine = Machine::findOrFail($id);
        $now = Carbon::now();
        $machine->start = $now;
        $end = $now->copy();
        if($machine->type == "washing-machine")
        {
            $end->addMinutes(32);
            $machine->end = $end;
        }
        else if($machine->type == "dryer")
        {
            $end->addMinutes(28);
            $machine->end = $end;
        }
        $machine->save();
        return response()->json([
            "status" => "started",
            "ends" => $machine->end->format("Y-m-d H:i:s")
        ]);

    }

}
