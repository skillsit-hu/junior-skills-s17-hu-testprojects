<?php

namespace App\Http\Controllers;

use App\Http\Resources\LocationResource;
use App\Http\Resources\MachineResource;
use App\Models\Location;
use App\Models\Machine;
use Illuminate\Http\Request;
use Locale;
use PgSql\Lob;

class LocationController extends Controller
{
    public function index()
    {
        return LocationResource::collection(Location::all());
    }

    public function show(int $id)
    {
        return new LocationResource(Location::findOrFail($id));
    }

    public function machines(int $locationId)
    {
        return MachineResource::collection(Machine::where("location_id","=",$locationId)->orderBy("number")->get());
    }
}
