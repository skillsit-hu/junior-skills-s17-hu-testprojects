<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MachineResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            "id" => $this->id,
            "location_id" => $this->location_id,
            "number" => $this->number,
            "type" => $this->type,
            "size" => $this->size,
            "start" => $this->start,
            "end" => $this->end,
            "free" => is_null($this->end) || Carbon::now()->gt(Carbon::parse($this->end)),
        ];
        

    }
}
