<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class LocationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            "id" => $this->id,
            "name" => $this->name,
            "zip_code" => $this->zip_code,
            "city" => $this->city,
            "address" => $this->address,
            "number" => $this->number,
            "photo" => $this->photo,
            "map" => $this->map,
            "number_of_washing_machines" => $this->machines->where("type", "=","washing-machine")->count(),
            "number_of_dryers" => $this->machines->where("type", "=","dryer")->count(),
        ];
    }
}
