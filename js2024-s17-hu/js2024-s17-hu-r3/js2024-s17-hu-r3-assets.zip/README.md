# Mosoda API

## Összes mosoda adatai

GET `/api/locations`

Visszaadja az összes mosoda adatát egy tömbben. Részletes leírás megtalálható az egy mosoda adatai végpontnál.

```json
[
  {
    "id": 1,
    "name": "Szeged 01",
    "zip_code": "6720",
    "city": "Szeged",
    "address": "Dóm tér",
    "number": "1-2",
    "photo": "szeged.jpg",
    "map": "szeged-terkep.png",
    "number_of_washing_machines": 4,
    "number_of_dryers": 3
  },
  ...
]
```

## Egy mosoda adatai

GET `/api/locations/{location_id}`

Visszaadja a `{location_id}` által meghatározott mosoda adatait.

 - `id`: A mosoda/helyszín egyedi azonosítója
 - `name`: Megnevezés
 - `zip_code`: A helyszín irányítószáma
 - `city`: A város neve, ahol a mosoda található
 - `address`: A cím további rész
 - `number`: Házszám
 - `photo`: A városhoz tartozó kép megnevezése
 - `map`: A térképet ábrázoló kép neve
 - `number_of_washing_machines`: Mosógépek száma
 - `number_of_dryers` Szárítógépek száma

Például:

```json
{
  "id": 1,
  "name": "Szeged 01",
  "zip_code": "6720",
  "city": "Szeged",
  "address": "Dóm tér",
  "number": "1-2",
  "photo": "szeged.jpg",
  "map": "szeged-terkep.png",
  "number_of_washing_machines": 4,
  "number_of_dryers": 3
}
```


## Gépek listája

GET `/api/locations/{location_id}/machines`

Az adott helyszínen található összes mosó- és szárítógép adatait adja vissza.

```json
[
    {
    "id": 22,
    "location_id": 3,
    "number": 1,
    "type": "washing-machine",
    "size": 8,
    "start": "2024-04-04 09:08:53",
    "end": "2024-04-04 09:40:53",
    "free": true
    },
    ...
    {
    "id": 26,
    "location_id": 3,
    "number": 22,
    "type": "dryer",
    "size": 22,
    "start": "2024-04-04 19:21:41",
    "end": "2024-04-04 19:49:41",
    "free": true
    }
]
```

## Felhasználók listázása

GET `/api/users`

A regisztráció ellenőrzésére szolgál, illetve tesztadatok visszaadása a mosás indításához.

Megadja a felhasználók adatait. Kiemelten fontos a `name` és a `pin` mezők, ugyanis ezek szükségesek a mosás indításához.

Példa:

```json
[
  {
    "name": "NA1",
    "last_name": "Nagy",
    "first_name": "András",
    "email": "nagy.andras@example.com",
    "phone": "+36-30/303-03-03",
    "pin": "1234"
  }
]
```

## Felhasználó regisztrálása

POST `/api/users/register`

**Az elküldendő adatok neve egyezzenek meg az űrlapon található beviteli mezők nevével!**

A szerver számára küldendő minta adatok:

```json
{
    "last_name":"Vezetéknév",
    "first_name":"Keresztnév",
    "email":"email@example.com",
    "phone":"+36-70/707-70-70",
    "pin":"1234",
    "pin_confirmation":"1234"
}
```

Ahogy a mintán látható a felhasználó nevét a `last_name` és `first_name` tartalmazza.
Az elérhetőségeit `email` és `phone` néven küldd el.
A PIN kódot a `pin` értéke határozza meg, a megismételt kódot pedig `pin_confirmation` néven küldd el!

Lehetséges válasz sikeres regisztráció esetén 201-es HTTP státuszkóddal:

```json
{
    "name":"VK2",
    "last_name":"Vezetéknév",
    "first_name":"Keresztnév",
    "email":"email1@example.com",
    "phone":"+36-70/707-70-70",
    "pin":"1234"
}
```

Lehetséges válasz validálási hiba esetén 422-es HTTP státuszkóddal:

```json
{
    "message": "The email has already been taken.",
    "errors":{
        "email":["The email has already been taken."]
    }
}
```

- A hibaüzenet tartalmazza, hogy melyik mező érkezett meg hibásan.

A visszakapott `name` és `pin` kell majd a mosás indításához.
**Ezeket NEM kell az applikációnak eltárolnia**, elegendő leírni papírra, és az indításnál megadni!

 
### Validálás regisztrációnál

A szerver csak valid kódot fogad el, az itt meghatározott validációs szabályokat ellenőrizd frontenden is!

 - Minden mező kitöltése kötelező!
 - `last_name`: minimum 1 karakter, de legfeljebb 20 karakter lehet
 - `first_name`: minimum 1 karakter, de legfeljebb 20 karakter lehet
 - `email`: Legyen email formátumú, azaz legalább egy `@` jelet tartalmazzon, továbbá minimum 1 karakter, de legfeljebb 80 karakter lehet
 - `phone`: Feleljen meg az alábbi mintának: *"+36-70/707-70-70"*, a mintát jelenítse meg, ha a felhasználó elrontja
 - `pin`: minimum 1 karakter, de legfeljebb 12 karakter lehet
 - `pin_confirmation`: minimum 1 karakter, de legfeljebb 12 karakter lehet

## Mosás indítása

POST `/api/machines/{machine_id}/start`

**Az elküldendő adatok neve egyezzenek meg az űrlapon található beviteli mezők nevével!**

A szerver számára küldendő minta adatok:

```json
{
    "name":"NA1",
    "pincode":"1234",
    "machine_id":"26"
}
```

El kell küldeni a felhasználó nevét (`name`) és a PIN kódját (`pincode`) a beazonosításához. Továbbá az indítani kívánt eszköz azonosítóját `machine_id` néven. Utóbbi legyen a lenyomott "Indítás" gomb sorában lévő gép azonosítója. **Nem összekeverendő a gép sorszámával!**

Lehetséges válasz sikeres indítás esetén 200-as HTTP státuszkóddal:

```json
{
    "status":"started",
    "ends":"2024-04-01 19:43:48"
}
```

Lehetséges válasz ismeretlen felhasználó esetén 422-es HTTP státuszkóddal:

```json
{
    "message":"The selected name is invalid.",
    "errors":{
        "name":["The selected name is invalid."]
        }
    }
```