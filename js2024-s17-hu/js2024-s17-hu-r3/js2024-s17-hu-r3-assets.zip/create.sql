drop database if exists laundry;

create database laundry
character set utf8
collate utf8_hungarian_ci;