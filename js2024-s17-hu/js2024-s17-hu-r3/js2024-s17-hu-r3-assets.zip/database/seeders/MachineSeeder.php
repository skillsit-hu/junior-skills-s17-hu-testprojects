<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MachineSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table("machines")->insert([
            [
                "id" => 1,
                "location_id" => 1,
                "type" => "washing-machine",
                "number" => 1,
                "size" => 10, // kg
            ],
            [
                "id" => 2,
                "location_id" => 1,
                "type" => "washing-machine",
                "number" => 2,
                "size" => 10, // kg
            ],
            [
                "id" => 3,
                "location_id" => 1,
                "type" => "dryer",
                "number" => 21,
                "size" => 16, // kg
            ],
            [
                "id" => 4,
                "location_id" => 1,
                "type" => "washing-machine",
                "number" => 3,
                "size" => 10, // kg
            ],
            [
                "id" => 5,
                "location_id" => 1,
                "type" => "washing-machine",
                "number" => 4,
                "size" => 10, // kg
            ],
            [
                "id" => 6,
                "location_id" => 1,
                "type" => "dryer",
                "number" => 22,
                "size" => 16, // kg
            ],
            [
                "id" => 7,
                "location_id" => 1,
                "type" => "dryer",
                "number" => 23,
                "size" => 25, // kg
            ],




            [
                "id" => 8,
                "location_id" => 2,
                "type" => "washing-machine",
                "number" => 1,
                "size" => 8, // kg
            ],
            [
                "id" => 9,
                "location_id" => 2,
                "type" => "washing-machine",
                "number" => 2,
                "size" => 8, // kg
            ],
            [
                "id" => 10,
                "location_id" => 2,
                "type" => "washing-machine",
                "number" => 3,
                "size" => 10, // kg
            ],
            [
                "id" => 11,
                "location_id" => 2,
                "type" => "washing-machine",
                "number" => 4,
                "size" => 10, // kg
            ],

            [
                "id" => 12,
                "location_id" => 2,
                "type" => "washing-machine",
                "number" => 5,
                "size" => 10, // kg
            ],
            [
                "id" => 13,
                "location_id" => 2,
                "type" => "washing-machine",
                "number" => 6,
                "size" => 10, // kg
            ],
            [
                "id" => 14,
                "location_id" => 2,
                "type" => "washing-machine",
                "number" => 7,
                "size" => 16, // kg
            ],
            [
                "id" => 15,
                "location_id" => 2,
                "type" => "washing-machine",
                "number" => 8,
                "size" => 12, // kg
            ],

            [
                "id" => 16,
                "location_id" => 2,
                "type" => "dryer",
                "number" => 21,
                "size" => 12, // kg
            ],
            [
                "id" => 17,
                "location_id" => 2,
                "type" => "dryer",
                "number" => 22,
                "size" => 12, // kg
            ],

            [
                "id" => 18,
                "location_id" => 2,
                "type" => "dryer",
                "number" => 23,
                "size" => 16, // kg
            ],
            [
                "id" => 19,
                "location_id" => 2,
                "type" => "dryer",
                "number" => 24,
                "size" => 16, // kg
            ],

            [
                "id" => 20,
                "location_id" => 2,
                "type" => "dryer",
                "number" => 25,
                "size" => 12, // kg
            ],
            [
                "id" => 21,
                "location_id" => 2,
                "type" => "dryer",
                "number" => 26,
                "size" => 25, // kg
            ],


            // pécs


            [
                "id" => 22,
                "location_id" => 3,
                "type" => "washing-machine",
                "number" => 1,
                "size" => 8, // kg
            ],
            [
                "id" => 23,
                "location_id" => 3,
                "type" => "washing-machine",
                "number" => 2,
                "size" => 10, // kg
            ],
            [
                "id" => 24,
                "location_id" => 3,
                "type" => "washing-machine",
                "number" => 3,
                "size" => 16, // kg
            ],

            [
                "id" => 25,
                "location_id" => 3,
                "type" => "dryer",
                "number" => 21,
                "size" => 14, // kg
            ],
            [
                "id" => 26,
                "location_id" => 3,
                "type" => "dryer",
                "number" => 22,
                "size" => 22, // kg
            ],

           
           
        ]);
    }
}
