<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LocationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table("locations")->insert([
            [
                "id" => 1,
                "name" => "Szeged 01",
                "city" => "Szeged",
                "zip_code" => "6720",
                "address" => "Dóm tér",
                "number" => "1-2",
                "photo" => "szeged.jpg",
                "map" => "szeged-terkep.png",
            ],
            [
                "id" => 2,
                "name" => "Eger 02",
                "city" => "Eger",
                "zip_code" => "3300",
                "address" => "Dobó istván utca",
                "number" => "2",
                "photo" => "eger.jpeg",
                "map" => "eger-terkep.png",
            ],
            [
                "id" => 3,
                "name" => "Pécs 03",
                "city" => "Pécs",
                "zip_code" => "7621",
                "address" => "Kosutth tér",
                "number" => "8",
                "photo" => "pecs.jpg",
                "map" => "pecs-terkep.png",
            ],
        ]);
    }
}
