<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call(LocationSeeder::class);
        $this->call(MachineSeeder::class);

        DB::table("users")->insert([
            [
                "id" => 1,
                "name" => "NA1",
                "last_name" => "Nagy",
                "first_name" => "András",
                "phone" => "+36-30/303-03-03",
                "password" => "",
                "pin" => "1234",
                "email" => "nagy.andras@example.com",
            ]
        ]);
        // \App\Models\User::factory(10)->create();

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);
    }
}
