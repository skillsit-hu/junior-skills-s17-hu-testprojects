<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ReservationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("reservations")->insert([
            [
                "name" => "Tóth Aladár",
                "email" => "aladar.toth@example.com",
                "start" => "2023-04-10",
                "occasion" => "birthday",
            ],
            [
                "name" => "Nagy Andrea",
                "email" => "andrea.nagy@example.com",
                "start" => "2023-04-12",
                "occasion" => "wedding",
            ]
        ]);
    }
}
