<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("products")->insert([
            [
                "name" => "Fekete tea (kicsi)",
                "category" => "tea",
                "quantity" => 3,
                "unit" => "dl",
                "price" => "500",
                "available" => true,
            ],
            [
                "name" => "Fekete tea (nagy)",
                "category" => "tea",
                "quantity" => 5,
                "unit" => "dl",
                "price" => "800",
                "available" => true,
            ],
            [
                "name" => "Zöld tea (kicsi)",
                "category" => "tea",
                "quantity" => 3,
                "unit" => "dl",
                "price" => "500",
                "available" => true,
            ],
            [
                "name" => "Zöld tea (nagy)",
                "category" => "tea",
                "quantity" => 5,
                "unit" => "dl",
                "price" => "800",
                "available" => true,
            ],
            [
                "name" => "Rooibos tea (kicsi)",
                "category" => "tea",
                "quantity" => 3,
                "unit" => "dl",
                "price" => "600",
                "available" => false,
            ],
            [
                "name" => "Rooibos tea (nagy)",
                "category" => "tea",
                "quantity" => 5,
                "unit" => "dl",
                "price" => "900",
                "available" => false,
            ],
            [
                "name" => "Earl grey tea (kicsi)",
                "category" => "tea",
                "quantity" => 3,
                "unit" => "dl",
                "price" => "550",
                "available" => true,
            ],
            [
                "name" => "Earl grey tea (nagy)",
                "category" => "tea",
                "quantity" => 5,
                "unit" => "dl",
                "price" => "850",
                "available" => true,
            ],
            
        ]);


        DB::table("products")->insert([
            [
                "name" => "Amaretti (mini)",
                "category" => "cookie",
                "quantity" => 5,
                "unit" => "db",
                "price" => "650",
                "available" => true,
            ],
            [
                "name" => "Amaretti (kicsi)",
                "category" => "cookie",
                "quantity" => 10,
                "unit" => "db",
                "price" => "1300",
                "available" => true,
            ],
            [
                "name" => "Amaretti (nagy)",
                "category" => "cookie",
                "quantity" => 20,
                "unit" => "db",
                "price" => "2200",
                "available" => true,
            ],
            [
                "name" => "Zabkeksz (natúr)",
                "category" => "cookie",
                "quantity" => 3,
                "unit" => "db",
                "price" => "290",
                "available" => true,
            ],
            [
                "name" => "Zabkeksz (almás)",
                "category" => "cookie",
                "quantity" => 3,
                "unit" => "db",
                "price" => "290",
                "available" => false,
            ],
            [
                "name" => "Zabkeksz (csokis)",
                "category" => "cookie",
                "quantity" => 3,
                "unit" => "db",
                "price" => "420",
                "available" => true,
            ],
            [
                "name" => "Mignon (puncs)",
                "category" => "cookie",
                "quantity" => 1,
                "unit" => "db",
                "price" => "890",
                "available" => true,
            ],
            [
                "name" => "Mignon (csoki)",
                "category" => "cookie",
                "quantity" => 3,
                "unit" => "db",
                "price" => "890",
                "available" => true,
            ],
            [
                "name" => "Mignon (citrom)",
                "category" => "cookie",
                "quantity" => 1,
                "unit" => "db",
                "price" => "850",
                "available" => true,
            ],
            
        ]);


        DB::table("products")->insert([
            [
                "name" => "Espresso",
                "category" => "coffee",
                "quantity" => 27,
                "unit" => "ml",
                "price" => "540",
                "available" => true,
            ],
            [
                "name" => "Ristretto",
                "category" => "coffee",
                "quantity" => 22,
                "unit" => "ml",
                "price" => "510",
                "available" => true,
            ],
            [
                "name" => "Lungo",
                "category" => "coffee",
                "quantity" => 43,
                "unit" => "ml",
                "price" => "820",
                "available" => true,
            ],
            [
                "name" => "Latte Macchiato",
                "category" => "coffee",
                "quantity" => 3,
                "unit" => "dl",
                "price" => "1100",
                "available" => true,
            ],
            [
                "name" => "Doppio",
                "category" => "coffee",
                "quantity" => 50,
                "unit" => "ml",
                "price" => "890",
                "available" => true,
            ],
            [
                "name" => "Flat white",
                "category" => "coffee",
                "quantity" => 2,
                "unit" => "dl",
                "price" => "670",
                "available" => true,
            ],
            [
                "name" => "Americano",
                "category" => "coffee",
                "quantity" => 150,
                "unit" => "ml",
                "price" => "790",
                "available" => true,
            ],
            [
                "name" => "Mocha",
                "category" => "coffee",
                "quantity" => 150,
                "unit" => "ml",
                "price" => "790",
                "available" => true,
            ],
            [
                "name" => "Double Latte",
                "category" => "coffee",
                "quantity" => 4,
                "unit" => "dl",
                "price" => "1050",
                "available" => true,
            ],
            
        ]);
    }
}
