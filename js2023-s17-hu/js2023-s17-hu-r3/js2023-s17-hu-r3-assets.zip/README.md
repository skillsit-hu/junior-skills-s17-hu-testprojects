# Zacc Kávézó

## API

### Termékek

```
/api/products/{category}
```

A GET HTTP metódussal érhető el.

A megadott kategória termékeit jeleníti meg. Például a `/api/products/coffee` címen az összes kávé adatait adja meg.

Lehetséges kategóriák:
 - `coffee`
 - `cookie`
 - `tea`

Lehetséges válasz (részlet)


```json
[
    {
        "id": 18,
        "name": "Espresso",
        "category": "coffee",
        "quantity": 27,
        "unit": "ml",
        "price": 540,
        "available": 1
    },
    {
        "id": 19,
        "name": "Ristretto",
        "category": "coffee",
        "quantity": 22,
        "unit": "ml",
        "price": 510,
        "available": 1
    },
    ...
]
```
Egy termék leírása:

| Tulajdonság | Leírás                                                |
|-------------|-------------------------------------------------------|
|`id`         | A termék azonosítója                                  |
|`name`       | A termék megnevezése                                  |
|`category`   | A termék kategóriája                                  |
|`quantity`   | Az eladott mennyiség  pl.: 3                          |
|`unit`       | Az eladott mennyiség egysége  pl.: db                 |
|`price`      | Az adott termék ára a megadott kiszerelés esetén (Ft) |
|`available`  | A termék jelenleg elérhető, vagy sem (logikai)        |


### Foglalások

```
/api/reservations
```
A POST HTTP metódussal érhető el.

Az elvárt adatok

- `name`: Név
- `email`: E-mail
- `start`: a foglalás dátuma (ISO formátumú dátum YYYY-MM-DD)
- `occasion`: az alkalom. Csak `wedding`, `birthday` vagy `company` lehet az értéke.

Visszaadott értékek:

Siker esetén egy olyan JSON objektum, ami a feltöltött adatokon túl tartalmazza az adatbázisban létrejött `id`-t is. Mintakód és válasz hibás adatok esetén a validáció részben.

A táblázatban a jelenleg elérhető termékeket "✅", míg a nem elérhetőeket "❌" jellel jelöld.

## Foglalás űrlap

Az adatbeviteli mezők használják ki a HTML5 elemek lehetőségeit!

A név legyen szöveges beviteli mező, az email legyen email és a napba csak dátumot lehessen felvinni.

A legördülő lista az alábbi lehetőségeket sorolja fel:
 - Milyen alkalomra foglal?
 - Céges alkalom
 - Születésnap
 - Esküvő

### Űrlap validáció

Az űrlapot csak akkor küldd el a szervernek, ha a felhasználó elfogadta a szabályzatot.

Ellenkező esetben "A felhasználási feltételeket el kell fogadni!" hibaüzenetet jeleníts meg egy BS alert komponensben az űrlap alatt, ahogy a mintán látható!

A backend validálja az elküldött adatokat és hiba esetén a válaszban szerepelni fog egy `message`, ilyenkor azt kell megjeleníteni az űrlap alatt egy BS alert komponensben.

Lehetséges válasz üzenet: hibás adat esetén

```json
{
    "message": "Az E-mail kitöltése kötelező. (and 1 more error)",
    "errors": {
        "email": [
            "Az E-mail kitöltése kötelező."
        ],
        "occasion": [
            "Az alkalom kitöltése kötelező."
        ]
    }
}
```

Amennyiben sikeres volt, úgy a regisztrált rendelés adatai jönnek vissza.

```json
{
    "name": "Tóth Géza",
    "email": "geza.toth@example.com",
    "start": "2023-03-30",
    "occasion": "wedding",
    "id": 7
}
```