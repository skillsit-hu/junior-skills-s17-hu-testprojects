drop database if exists zacc;
create database zacc
character set utf8
collate utf8_hungarian_ci;