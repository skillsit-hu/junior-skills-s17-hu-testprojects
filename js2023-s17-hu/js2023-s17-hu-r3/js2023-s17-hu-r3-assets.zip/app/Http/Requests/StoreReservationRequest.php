<?php

namespace App\Http\Requests;

use Closure;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreReservationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            "name" => "required|max:50",
            "email" => "required|max:80",
            "start" => [
                "required",
                "date",
                "unique:reservations,start"
            ],
            "occasion" => [
                "required",
                Rule::in(["wedding", "birthday", "company"])
            ],
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'name.required' => 'A Név kitöltése kötelező.',
            'email.required' => 'Az E-mail kitöltése kötelező.',
            'start.required' => 'A Nap kitöltése kötelező.',
            'occasion.required' => 'Az alkalom kitöltése kötelező.',

            'name.max' => 'A Név maximális hossza 50 karakter.',
            'email.max' => 'Az E-mail maximális hossza 80 karakter.',
            'start.date' => 'A Nap formátuma: YYYY-MM-DD.',
            'start.unique' => 'Sajnos erre a napra már van foglalás.',
            'occasion.in' => 'Az Alkalom értéke csak "wedding", "birthday", vagy "company" lehet.',
        ];
    }
}
